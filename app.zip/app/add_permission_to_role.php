<?php
include_once "classes/Db.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $db = new Db("localhost", "root", "", "news");

    $role = $_POST['role'];
    $permission = $_POST['permission'];

    // Sprawdź, czy rola istnieje w bazie danych
    $roleId = getRoleIdByName($db, $role);
    if ($roleId) {
        // Dodaj nowe uprawnienie do roli
        addPermissionToRole($db, $roleId, $permission);
        echo "Uprawnienie zostało dodane do roli.";
    } else {
        echo "Wybrana rola nie istnieje.";
    }
}

function getRoleIdByName($db, $roleName)
{
    $sql = "SELECT id FROM role WHERE role_name = ?";
    $stmt = $db->prepare($sql);
    $stmt->bind_param("s", $roleName);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    $roleId = $row['id'];
    $stmt->close();
    return $roleId;
}

function addPermissionToRole($db, $roleId, $permission)
{
    $sql = "INSERT INTO role_privilege (role_id, privilege_id) VALUES (?, ?)";
    $stmt = $db->prepare($sql);
    $stmt->bind_param("is", $roleId, $permission);
    $stmt->execute();
    $stmt->close();
}
?>

