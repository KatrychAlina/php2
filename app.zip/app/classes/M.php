<?php
namespace PHPMailer\src\PHPMailer;
namespace PHPMailer\src\Exception;
use PHPMailer\PHPMailer\Exception;
use PHPMailer\PHPMailer\PHPMailer;
require './PHPMailer/src/Exception.php';
require './PHPMailer/src/PHPMailer.php';
require './PHPMailer/src/SMTP.php';
$m=new M();
//$m->send_email('adres_odbiorcy@gmail.com','hasło jednorazowe');
class M
{
 public function send_email($address,$content){
 try
 {
 $mail = new PHPMailer;
 $mail->isSMTP(); // Set mailer to use SMTP
 $mail->Host = 'poczta.o2.pl'; // Specify main and backup SMTP servers
 $mail->SMTPAuth = true; // Enable SMTP authentication
 $mail->Username = 'konto_email_do_wysylania_maiłi@o2.pl'; // SMTP username
 $mail->Password = 'hasło do konta do wysyłki'; // SMTP password
 $mail->SMTPSecure = 'tls'; // Enable encryption, 'ssl' also accepted
 $mail->From = 'konto_email_do_wysylania_maiłi@o2.pl';
 $mail->FromName = 'OTP source';
 $mail->addAddress($address);
 $mail->WordWrap = 40; 
 $mail->isHTML(true); 
        $mail->Subject = 'Your security code';
 $mail->Body = 'This is your authentication code <B>'.$content.'</B>';
 $mail->AltBody = 'This is your authentication code '.$content.'';
 if (!$mail->send())
 {
 echo 'Message could not be sent.';
 echo 'Mailer Error: ' . $mail->ErrorInfo;
 }
 else {
 echo 'Message has been sent';
 }
 }catch
 (Exception $e){
 echo "Exception &nbsp" . $e->getMessage();
 }
 }
}