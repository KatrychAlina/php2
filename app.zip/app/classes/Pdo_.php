<?php
session_start();
require_once 'C:\xampp\htdocs\app\htmlpurifier-4.15.0\library\HTMLPurifier.auto.php';
require_once 'Aes.php';
//require_once 'C:\xampp\htdocs\app\PHPMailer\src\PHPMailer.php';
include_once 'classes/M.php';

class Pdo_
{
    private $db;
    private $purifier;
    private $m;
    public function __construct()
    {
        $config = HTMLPurifier_Config::createDefault();
        $this->purifier = new HTMLPurifier($config);
       $this->m = new PHPMailer\src\Exception\M;
        try {
            $this->db = new PDO('mysql:host=localhost;dbname=news', 'app_user', 'student');
        } catch (PDOException $e) {
            // add relevant code
            die();
        }
        
    }


    public function add_user($login, $email, $password)
    {
        $login = $this->purifier->purify($login);
        $email = $this->purifier->purify($email);
       
        // generate salt
        $salt = bin2hex(random_bytes(32));

        try {
            $sql = "INSERT INTO `user` (`login`, `email`, `hash`, `salt`, `id_status`, `password_form`)
                    VALUES (:login, :email, :hash, :salt, :id_status, :password_form)";
            
            // concatenate password and salt, then hash
            $password = hash('sha512', $password . $salt);
            
            $data = [
                'login' => $login,
                'email' => $email,
                'hash' => $password,
                'salt' => $salt,
                'id_status' => '1',
                'password_form' => '1'
            ];

            $this->db->prepare($sql)->execute($data);
        } catch (Exception $e) {
            //modify the code here
            print 'Exception' . $e->getMessage();
        }
    }

    public function log_user_in($login, $password, $sms_code)
{
    $login = $this->purifier->purify($login);

    try {
        $sql = "SELECT id, hash, salt, login, email, sms_code FROM user WHERE login=:login";
        $stmt = $this->db->prepare($sql);
        $stmt->execute(['login' => $login]);
        $user_data = $stmt->fetch();

        // concatenate password and salt, then hash
        $hash = hash('sha512', $password . $user_data['salt']);

        if ($hash == $user_data['hash'] && $sms_code == $user_data['sms_code']) {
            
            echo 'login successful<BR/>';
            echo 'You are logged in as: ' . $user_data['login'] . '<BR/>';
            // set session variables
            
           $_SESSION['user_id'] = $user_data['id'];
            $_SESSION['expire_time'] = time() + 300; // expire time = 5 minutes from now
        } else {
            echo 'login FAILED<BR/>';
        }
    } catch (Exception $e) {
        //modify the code here
        print 'Exception' . $e->getMessage();
    }
}


   // zmiana hasla
    public function change_password($login, $old_password, $new_password)
{
    $login = $this->purifier->purify($login);

    try {
        $sql = "SELECT id,hash,salt FROM user WHERE login=:login";
        $stmt = $this->db->prepare($sql);
        $stmt->execute(['login' => $login]);
        $user_data = $stmt->fetch();

        $old_password = hash('sha512', $old_password . $user_data['salt']);
        if ($old_password != $user_data['hash']) {
            echo 'Old password is incorrect<BR/>';
            return;
        }

        $salt = bin2hex(random_bytes(32));
        $new_hash = hash('sha512', $new_password . $salt);

        $sql = "UPDATE user SET hash=:hash, salt=:salt WHERE id=:id";
        $data = [
            'hash' => $new_hash,
            'salt' => $salt,
            'id' => $user_data['id'],
        ];
        $this->db->prepare($sql)->execute($data);

        echo 'Password changed successfully<BR/>';
    } catch (Exception $e) {
        // modify the code here
        print 'Exception' . $e->getMessage();
    }
}

public function get_user_by_id($user_id)
{
    try {
        $sql = "SELECT id, login, email FROM user WHERE id=:user_id";
        $stmt = $this->db->prepare($sql);
        $stmt->execute(['user_id' => $user_id]);
        $user_data = $stmt->fetch();
        return $user_data;
    } catch (Exception $e) {
        //modify the code here
        print 'Exception' . $e->getMessage();
    }
}

public function get_privileges($login)
 {
    $login = $this->purifier->purify($login);
    try {
          $sql = "SELECT p.id,p.name FROM privilege p"
          ." INNER JOIN user_privilege up ON p.id=up.id_privilege"
          ." INNER JOIN user u ON u.id=up.id_user"
          ." WHERE u.login=:login";
           $stmt = $this->db->prepare($sql);
           $stmt->execute(['login' => $login]);
           $data = $stmt->fetchAll();
           foreach ($data as $row) {
                $privilege=$row['name'];
                $_SESSION[$privilege]='YES';
             }
            $data['status']='success';
            return $data;
        } catch (Exception $e) {
            print 'Exception' . $e->getMessage();
         }
 return [
 'status' => 'failed'
 ];
 }
 
 
 

}

