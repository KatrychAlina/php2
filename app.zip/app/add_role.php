<?php
session_start();
include_once "classes/Db.php";

// Sprawdzenie, czy użytkownik jest zalogowany
if (isset($_SESSION['user_id'])) {
    // Pobranie identyfikatora zalogowanego użytkownika
    $user_id = $_SESSION['user_id'];

    // Wyświetlanie formularza do dodawania roli
    echo '<h2>Dodawanie roli</h2>';
    echo '<form method="POST" action="add_role.php">';
    echo '<label for="role">Wybierz rolę:</label>';
    echo '<select name="role" id="role">';
    echo '<option value="1">user</option>';
    echo '<option value="2">admin</option>';
    // Dodaj więcej opcji ról, jeśli jest ich więcej
    echo '</select>';
    echo '<input type="submit" value="Dodaj">';
    echo '</form>';

    // Obsługa dodawania roli
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        // Pobranie wybranej roli z formularza
        $selectedRole = $_POST['role'];

        // Wykonanie operacji dodawania roli
        $db = new Db("localhost", "root", "", "news");

        // Sprawdzenie, czy udało się połączyć z bazą danych
        if ($db->connect_errno) {
            echo 'Wystąpił błąd podczas połączenia z bazą danych: ' . $db->connect_error;
            exit();
        }

        // Przygotowanie zapytania SQL do dodania roli
        $sql = 'INSERT INTO user_role (user_id, role_id) VALUES (?, ?)';
        $stmt = $db->prepare($sql);
        $stmt->bind_param('ii', $user_id, $selectedRole);

        // Wykonanie zapytania SQL
        if ($stmt->execute()) {
            echo 'Rola została dodana.';
        } else {
            echo 'Wystąpił błąd podczas dodawania roli: ' . $stmt->error;
        }

        // Zamknięcie połączenia i zwolnienie zasobów
        $stmt->close();
        $db->close();
    }
} else {
    echo 'Nie jesteś zalogowany. <a href="indx.php">Zaloguj się</a>';
}
?>

