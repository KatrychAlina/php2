<?php
// edit_message.php

// Tutaj należy umieścić kod dołączający plik z konfiguracją bazy danych lub inicjalizujący połączenie z bazą danych

// Sprawdzenie, czy parametr `id` został przekazany w adresie URL
if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Pobranie wiadomości o danym `$id`
    $db = new Db("localhost", "root", "", "news");
    $query = "SELECT * FROM message WHERE id = '$id'";
    $message = $db->select($query)[0];

    // Sprawdzenie, czy formularz został przesłany
    if (isset($_POST['update_message'])) {
        $new_content = $_POST['message'];

        // Tutaj należy umieścić kod aktualizujący treść wiadomości o danym `$id`
        $update_query = "UPDATE message SET message = '$new_content' WHERE id = '$id'";
        $db->query($update_query);

        // Przekierowanie użytkownika po wykonaniu akcji
        header("Location: messages.php");
        exit();
    }
} else {
    // Przekierowanie użytkownika w przypadku braku parametru `id`
    header("Location: error.php");
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edycja wiadomości</title>
</head>
<body>
    <h1>Edycja wiadomości</h1>

    <form method="POST" action="">
        <label for="content">Treść wiadomości:</label><br>
        <textarea id="message" name="message"><?php echo $message->message; ?></textarea><br>

        <input type="submit" name="update_message" value="Aktualizuj">
    </form>
</body>
</html>


