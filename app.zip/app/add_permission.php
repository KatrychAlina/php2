<?php
session_start();
include_once "classes/Db.php";
// Sprawdzenie, czy użytkownik jest zalogowany
if (isset($_SESSION['user_id'])) {
    // Pobranie identyfikatora zalogowanego użytkownika
    $user_id = $_SESSION['user_id'];

    // Wyświetlanie formularza do dodawania uprawnień
    echo '<h2>Dodawanie uprawnień</h2>';
    echo '<form method="POST" action="add_permission.php">';
    echo '<label for="permission">Wybierz uprawnienie:</label>';
    echo '<select name="permission" id="permission">';
    echo '<option value="1">add message</option>';
    echo '<option value="2">delete message</option>';
    echo '<option value="3">display private</option>';
    echo '<option value="4">edit message</option>';
    // Dodaj więcej opcji uprawnień, jeśli jest ich więcej
    echo '</select>';
    echo '<input type="submit" value="Dodaj">';
    echo '</form>';

    // Obsługa dodawania uprawnień
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        // Pobranie wybranego uprawnienia z formularza
        $selectedPermission = $_POST['permission'];

        // Wykonanie operacji dodawania uprawnień
        $db = new Db("localhost", "root", "", "news");

        // Sprawdzenie, czy udało się połączyć z bazą danych
        if ($db->connect_errno) {
            echo 'Wystąpił błąd podczas połączenia z bazą danych: ' . $db->connect_error;
            exit();
        }

        // Przygotowanie zapytania SQL do dodania uprawnienia
        $sql = 'INSERT INTO user_privilege (id_user , id_privilege) VALUES (?, ?)';
        $stmt = $db->prepare($sql);
        $stmt->bind_param('ii', $user_id, $selectedPermission);

        // Wykonanie zapytania SQL
        if ($stmt->execute()) {
            echo 'Uprawnienie zostało dodane.';
        } else {
            echo 'Wystąpił błąd podczas dodawania uprawnienia: ' . $stmt->error;
        }
        ini_set('display_errors', 0);
         error_reporting(E_ALL & ~E_NOTICE & ~E_DEPRECATED & ~E_STRICT);

        // Zamknięcie połączenia i zwolnienie zasobów
        $stmt->close();
        $db->close();
    }
} else {
    echo 'Nie jesteś zalogowany. <a href="login.php">Zaloguj się</a>';
}
?>

